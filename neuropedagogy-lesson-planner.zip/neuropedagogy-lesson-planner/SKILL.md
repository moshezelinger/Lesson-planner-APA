---
name: neuropedagogy-lesson-planner
description: "Build lesson plans (מערכי שיעור) grounded in the APA Top 20 psychology principles (עקרונות נוירופדגוגיים) for any school subject and grade. Reads teacher-provided learning-unit documents (Word) and presentations (PowerPoint), maps existing exercises into a four-phase lesson structure, tags every move with the principle it serves, respects curriculum hour budgets, and outputs editable Markdown (Word conversion only after editing is done). Also maps the 20 principles across a yearly curriculum (macro planning). Use whenever a teacher uploads a learning unit or presentation, asks to build or split lessons, or mentions מערך שיעור, מערכי שיעור, יחידת לימוד, מתווה שיעור, עקרונות נוירופדגוגיים, 20 העקרונות, תוכנית שנתית, בניית שיעור, הכנת מערך, lesson plan, learning unit, teaching unit, or APA top 20 — even without naming this skill."
---

# Neuropedagogy Lesson Planner

## Overview

Turn a teacher's own materials into concrete, time-budgeted lesson plans built on the APA "Top 20 Principles From Psychology for PreK-12 Teaching and Learning". The skill works for any subject and any grade. It operates on two levels:

- **Level A — Macro**: spread the 20 principles across a yearly curriculum (units × emphasized principles × pedagogical logic).
- **Level B — Micro** (the main use): build the individual lessons of one learning unit from the teacher's unit document and presentation.

Four commitments shape everything this skill produces:

1. **Subject content comes only from the teacher's materials.** Pedagogy may be generated; content may not. This is what prevents hallucinated facts inside a lesson plan.
2. **Existing exercises are reused before new ones are written.** The teacher already built a presentation; the plan organizes it, it does not replace it.
3. **Hour budgets are real constraints**, not decoration. A plan that overflows its hours is a failed plan.
4. **Every pedagogical move is tagged with the principle it serves**, so the teacher always sees why a move is there.

## Sources, in order of preference

1. Files the teacher uploaded in this conversation (unit document, presentations).
2. Project files, if present: the full APA Top 20 document, a macro mapping if one exists, teaching-methods files, teacher notes and emphases, curriculum hour tables. Read what exists; never assume what doesn't.
3. `references/twenty_principles_compact.md` — only as a fallback when the full APA document is not available in the project or the conversation.

A subject-specific mapping (for example, a physics one) may exist in the project files. Treat it as an example of the approach applied to one subject, not as the content of this skill. Use it to see the style of macro mapping and unit-level logic, then derive the actual principle clusters from the teacher's own subject and materials.

If a needed fact is missing — total hours, grade level, lesson length, mandatory activities — ask the teacher. Do not guess and do not fill from general knowledge.

## Language

Write all teacher-facing output in the language of the teacher's materials, which is usually Hebrew. Hebrew output must read as native Hebrew: prefer verbs over verbal nouns, vary sentence structure, avoid anglicized phrasing. Keep principle numbers as digits (עיקרון 12) so plans stay scannable. If the materials are in English or another language, match it.

## Working mode

Default is **step-by-step**: deliver one stage, wait for the teacher's confirmation, then continue. Errors caught at the intake stage cost one correction; errors discovered after all lessons are written cost a rewrite of everything. Run end-to-end without checkpoints only when the teacher explicitly asks for it (e.g. "בנה הכל", "תריץ עד הסוף", "run it all"). At each checkpoint ask at most one focused question.

## Level B workflow: lessons for one unit

### Step 1 — Read everything before planning anything

Read the unit document and every presentation in full, using the document-reading skills. While reading each presentation, build an **exercise inventory**: for every exercise, demonstration, discussion prompt, or activity slide, record the slide number, what it asks, and which content section it belongs to. Slide numbers matter — the final plan tells the teacher "שקף 12", not "התרגיל על מהירות".

Also collect from the materials: the content sections and their order, stated goals, mandatory experiments or activities, misconceptions if the document lists them, and any hour allocation.

### Step 2 — Intake table (checkpoint 1)

Fill and present this table. Anything not found in the materials is marked **הצעה לאישור** and must not later be treated as fact without the teacher's confirmation.

| שדה | תוכן |
|---|---|
| שם היחידה, מקצוע, שכבה | |
| סך שעות ואורך שיעור (45 או 90 דק') | |
| מיקום בשנה | פתיחה / אמצע / סוף |
| עקרונות מודגשים ביחידה | from the macro map if one exists; otherwise propose 4–6 with a one-line rationale each |
| תפיסות שגויות נפוצות בנושא | from the materials; otherwise propose, clearly marked |
| שאלת חיזוי או פתיח מעורר | |
| התנסויות ופעילויות חובה | |
| מטרות קרובות (3–5) | |
| כלי הערכה מעצבת ומסכמת | |
| מלאי תרגילים קיימים | slide numbers + one-line description each |

**How to propose principles when no macro map exists.** Match the cluster to the content's nature and its position in the year. Year-opening units carry culture-building (11, 14, 16, 17). Misconception-heavy topics carry conceptual change (2) together with mastery goals and proximal goals (10, 12). Formula- or procedure-heavy topics carry concept-before-procedure and transfer (4) with practice and feedback (5, 6). Experiment- and project-rich units carry self-regulation and social learning (7, 13). Year-end application units carry transfer, creativity, and assessment literacy (4, 8, 18, 19, 20). Choose 4–6 principles, never all twenty — emphasis means selection.

### Step 3 — Unit skeleton (checkpoint 2)

Split the unit's hours into lessons. Present a table: lesson number, title, one goal phrased "בסוף השיעור נצליח ל...", main content, which existing slides and exercises it uses, emphasized principles, and minutes. Verify the minutes sum exactly to the unit's allocation before presenting. This skeleton is the teacher's map of the unit; do not write full plans until it is approved.

### Step 4 — Full lesson plans (checkpoint per lesson)

In step-by-step mode write one lesson, collect feedback, then continue — a correction on lesson 1 improves every later lesson for free.

Every lesson follows the four-phase structure:

| שלב | זמן (שיעור 45 דק') | ליבת השלב | עקרונות |
|---|---|---|---|
| פתיחה | 5–10 | שאלת חיזוי שכל תלמיד מתחייב לה לפני שרואים את התוצאה; יעד שיעור אחד ספציפי על הלוח; רוטינת פתיחה קבועה | 1, 2, 9, 12, 16 |
| הקניה | 15–20 | בנייה מהמוכר אל החדש; הרעיון לפני הנוסחה או הפרוצדורה; אותו רעיון בכמה ייצוגים; עימות מכוון עם תפיסה שגויה דרך נתון שסותר אותה; בדיקות הבנה קצרות ותכופות | 2, 3, 4, 6 |
| תרגול והתנסות | 15–20 | תרגול מרווח ומשולב שמחזיר גם חומר קודם; משוב ספציפי וקשור ליעד; התלמיד מתכנן, מנטר ומסיק; עבודה בקבוצות; הערכה אישית ממוקדת מאמץ ואסטרטגיה | 5, 6, 7, 10, 13 |
| סיכום | 5–10 | כרטיס יציאה שמזין את תכנון השיעור הבא; רפלקציה קצרה על מה הובן ומה לא; חיבור לחיים ולשיעור הבא; הכרה במאמץ | 4, 7, 14, 18, 20 |

For 90-minute lessons scale the two middle phases, not the opening and closure. Principles 11, 14, 15, 17 run through every phase of every lesson; 8 and 19 live mostly in the planning stage. The unit's emphasized principles from the intake get the spotlight; the table above is the standing routine baseline.

Rules while writing a lesson:

- Place existing exercises first. Every reused item carries its source in parentheses: (שקף 14) or (עמ' 6 במסמך).
- Create new items only where a mandatory component has no match in the materials — typically the prediction question, quick comprehension checks, and the exit ticket. Mark each one **[חדש]**.
- Tag every move with its principle number in parentheses.
- Give each phase its minutes and verify the phase minutes sum to the lesson length.

### Step 5 — Quality gate

Before delivering any output, verify four things: minutes sum correctly at both the lesson and the unit level; every emphasized principle appears at least once across the unit and it is clear where; every content item traces to a slide or page, or is marked [חדש]; no subject fact appears that is absent from the materials. If a check fails, fix the plan before presenting it — do not deliver and disclaim.

### Step 6 — Output, iteration, and Word

Write the output as Markdown files — one per lesson plus a short unit overview containing the skeleton table — because the teacher edits the Markdown directly. Iterate on the Markdown for as long as the teacher wants. Only when the teacher says editing is finished, offer conversion to a Word document (one per unit, RTL layout for Hebrew). Do not produce Word earlier: iterating on content inside a formatted document wastes both sides' time.

## Level A workflow: macro mapping

Use this level when the teacher brings a yearly curriculum, or asks to plan a year, and no principle mapping exists yet.

1. Read the curriculum materials; extract the units, their hour allocations, and the content nature of each unit.
2. Assign each unit an emphasized cluster of 4–6 principles with a one-line pedagogical logic, using the same content-nature heuristics described in Step 2 above. Ensure all twenty principles appear at least once across the year.
3. Present the mapping as a table: unit, position in year, hours, emphasized principles, logic. Include the four-phase lesson structure as the standing routine layer that runs beneath every unit.
4. Once approved, this mapping feeds every Level B run for that curriculum, so the intake table's principle row is filled from it instead of proposed anew.

## Output format

ALWAYS use this structure for a lesson file:

```
# [שם היחידה] — שיעור X מתוך Y: [כותרת]

**יעד השיעור:** בסוף השיעור נצליח ל...
**זמן:** XX דקות | **עקרונות מודגשים:** 2, 6, 12

## פתיחה (X דק')
- [המהלך, מה המורה עושה ומה התלמיד עושה] (עיקרון N) (שקף M / [חדש])

## הקניה (X דק')
- ...

## תרגול והתנסות (X דק')
- ...

## סיכום (X דק')
- ...

**חומרים:** שקפים בשימוש, ציוד, דפי עבודה
**לוח זמנים:** טבלה קצרה של שלבי השיעור שסכומה שווה לאורך השיעור
```

The unit overview file contains: the approved intake table, the lesson skeleton table, and a principle-coverage line showing where each emphasized principle appears.

## Hard rules against invention

- Subject facts, definitions, data, and exercise content come only from the teacher's materials. If a plan needs an example the materials do not contain, ask the teacher or leave a clearly marked placeholder for them to fill.
- Pedagogical scaffolds — routines, question stems, exit-ticket formats, feedback phrasing — may be generated freely; that is this skill's job. But the content inside them must come from the materials.
- Proposed misconceptions or prediction questions not found in the materials are marked הצעה לאישור המורה and are never silently woven into later lessons as established fact.
- Never invent hour allocations, curriculum requirements, or mandatory activities.

## Environment notes (Claude-specific)

Read .docx and .pptx inputs through the document skills before planning, and record slide numbers during the pptx read. Produce the Markdown with create_file and share it with present_files. For the final Word export use the docx skill, with RTL conventions for Hebrew documents. Everything above this section is platform-neutral and can be reused as system instructions in another assistant.
