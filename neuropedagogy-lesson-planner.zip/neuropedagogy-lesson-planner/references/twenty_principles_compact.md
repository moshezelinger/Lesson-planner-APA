# The APA Top 20 Principles — Compact Reference

Fallback only. When the full APA document ("Top 20 Principles From Psychology for PreK-12 Teaching and Learning") is available in the project files or the conversation, read it instead — it contains the explanations and the full teacher-relevance lists. This file gives one Hebrew statement per principle (reusable verbatim in Hebrew output) plus the key classroom moves.

## A. Cognition and learning (1–8)

**1.** אמונות התלמיד על האינטליגנציה ועל היכולת שלו משפיעות על התפקוד הקוגניטיבי ועל הלמידה.
Moves: attribute failure to effort/strategy, not ability; praise effort and strategy; treat mistakes as part of learning; offer help to everyone, not just some.

**2.** מה שהתלמיד כבר יודע משפיע על מה שילמד.
Moves: assess prior knowledge before teaching; build from the known; for misconceptions, create cognitive conflict — elicit a prediction, show contradicting evidence, rebuild.

**3.** ההתפתחות הקוגניטיבית אינה כובלת את הלמידה לשלבי גיל נוקשים.
Moves: pitch material moderately above current level with support; use mixed-ability groups; don't withhold challenge as "too hard for the age".

**4.** הלמידה תלוית הקשר; העברה להקשר חדש אינה מובנת מאליה ויש לטפח אותה.
Moves: teach the idea before the formula/procedure; same concept in multiple representations and contexts; make real-world application explicit; compare contexts.

**5.** רכישת ידע ומיומנות לטווח ארוך נשענת בעיקר על תרגול.
Moves: spaced and interleaved practice; frequent short practice tests; bring back earlier material; design practice around what students already know.

**6.** משוב בהיר, מסביר וניתן בזמן חיוני ללמידה.
Moves: specific, goal-linked, timely feedback; say what to do next; avoid generic "כל הכבוד"; frequent quick comprehension checks.

**7.** ויסות עצמי מסייע ללמידה ואפשר ללמד אותו.
Moves: clear goals and success criteria; break tasks into components; students plan, monitor, and conclude in activities; short reflection on what is and isn't understood.

**8.** אפשר לטפח יצירתיות.
Moves: allow multiple valid solution paths; prompts like "המציאו", "דמיינו ש", "חזו"; group problem-solving with presentation to varied audiences.

## B. Motivation (9–12)

**9.** מוטיבציה פנימית מנבאת הנאה והצלחה יותר מחיצונית.
Moves: novelty and surprise in openings; give choice where possible; frame grades as information, not reward and punishment.

**10.** מטרות שליטה מנבאות התמדה ועיבוד עמוק יותר ממטרות ביצוע.
Moves: emphasize individual progress, not comparison; evaluate privately; mixed-ability cooperative groups; mistakes as learning opportunities.

**11.** ציפיות המורה מעצבות הזדמנויות, מוטיבציה ותוצאות.
Moves: treat a weak history as a hypothesis, not a verdict; self-check for unequal treatment (seating, participation, feedback detail); never give up on a student.

**12.** מטרות קרובות, ספציפיות ומאתגרות במידה מניעות יותר ממטרות רחוקות וכלליות.
Moves: one specific lesson goal on the board ("נצליח ל..."); break units into 3–5 proximal goals; keep a written, jointly checked progress record.

## C. Social and emotional context (13–15)

**13.** הלמידה מתרחשת בהקשרים חברתיים מרובים.
Moves: peer explaining and listening; shared classroom culture with common vocabulary; connect curriculum to students' backgrounds and community.

**14.** יחסים בין-אישיים ותקשורת חיוניים להוראה ולהתפתחות רגשית-חברתית.
Moves: clear norms for respectful interaction; teach and practice communication (asking, clarifying, giving feedback); model active listening; recognize class effort.

**15.** רווחה רגשית משפיעה על ביצוע, למידה והתפתחות.
Moves: emotional vocabulary and regulation strategies; a climate where every student is accepted and supported; monitor that your encouragement reaches everyone.

## D. Classroom management (16–17)

**16.** ציפיות התנהגות נלמדות ואפשר ללמד אותן כמו תוכן.
Moves: fixed opening routine; teach rules like academic content — present, practice, feedback, reinforce; the first two weeks of the year are the critical window.

**17.** ניהול כיתה אפקטיבי = ציפיות גבוהות + יחסים חיוביים עקביים + תמיכה גבוהה.
Moves: predictable structure and consistently enforced rules, paired with warm relationships; high ratio of positive statements; structure without support is not enough.

## E. Assessment (18–20)

**18.** הערכה מעצבת והערכה מסכמת שתיהן חשובות אך שונות בגישה ובפרשנות.
Moves: exit tickets read the same day and feeding the next lesson; keep the gap between formative check and intervention short; use data to adjust your own teaching.

**19.** מדידה טובה נשענת על סטנדרטים ברורים של תקפות, מהימנות והוגנות.
Moves: align assessment with what was actually taught; enough and varied questions per topic; base high-stakes decisions on multiple measures.

**20.** הפקת משמעות מנתוני הערכה תלויה בפרשנות בהירה, מתאימה והוגנת.
Moves: interpret a test only for what it was built to measure; communicate limitations; avoid conclusions broader than the data.
